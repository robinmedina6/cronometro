<?php
header("location:../resultados.php");
?>