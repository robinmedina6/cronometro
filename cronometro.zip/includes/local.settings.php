<?php 
/*error_reporting(E_ALL);
ini_set('display_errors', '1');
$db_host = 'localhost'; 
$db_username = 'u722381250_admin'; 
$db_password = 'joagjaedjuji6'; 
$db_database = 'u722381250_crono'; */

$db_host = 'localhost'; 
$db_username = 'root'; 
$db_password = ''; 
$db_database = 'cronometro';

$nombresw="cronometro";
date_default_timezone_set("America/Bogota"); 
setlocale(LC_TIME,"spanish","es_CO"); 
?>